Cores utilizadas
    --Gray: #545864;
    --Contato:#36393D;
    --ContatoPreTransicao:#232629;
    --Geek:#FFD439;

Fontes utilizadas:

Staatliches,arial
Designed by Brian LaRossa, Erica Carras

Criado  no visual code
Carrosel utilizado bootstrap
efeito fade criado em js

