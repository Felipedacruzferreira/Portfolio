
    window.sr = ScrollReveal({reset:true});
    sr.reveal('.Post_1',{
        rotate:{x:0,y:80,z:0},
        duration:2000
    });

        sr.reveal('.Post_2',{
        rotate:{x:0,y:80,z:0},
        duration: 3000
                });
                
            sr.reveal('.Post_4',{
                rotate:{x:0,y:80,z:0},
                duration: 3000
            });
                sr.reveal('.Post_5',{
                    rotate:{x:0,y:80,z:0},
                    duration: 3000
                });
                sr.reveal('#Videos',{
                    rotate:{x:0,y:80,z:0},
                    duration: 3000
                });
                sr.reveal('.FotoAlinhamento',{
                    rotate:{x:0,y:80,z:0},
                    duration: 3000
                });
                sr.reveal('.twitter-tweet',{
                    rotate:{x:0,y:80,z:0},
                    duration: 2000
                });
                sr.reveal('#VejaMais',{
                    rotate:{x:0,y:80,z:0},
                    duration: 5000
                });
                sr.reveal('.NoticiaDestaque',{
                   
                    duration: 5000
                });
                
                sr.reveal('.Noticia',{
                    
                    duration: 5000
                });
                sr.reveal('p',{
                    
                    duration: 5000
                });
                sr.reveal('iframe',{
                    
                    duration: 5000
                });

 